document.addEventListener("DOMContentLoaded", function() {
    // Your fetch and content update code here
    const navbarContainer = document.getElementById("homeContainer");
    fetch("home.html")
    .then(response => response.text())
    .then(content => {
        navbarContainer.innerHTML = content;
    });
});
